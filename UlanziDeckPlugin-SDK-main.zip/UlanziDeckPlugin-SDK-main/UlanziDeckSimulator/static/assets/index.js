let ulanziLog = null; // 日志节点
let plugins = null; // 插件列表
let customMenu = null; // 自定义菜单节点
let config = {
  "language": "zh_CN",
  "loadAction": "no",
  "runMain": "no",
  "rootPath": "",
  serverPort: window.location.port
}  //默认配置

let activeKeys = {} // 当前激活的插件列表
let currentActiveKey = ''; // 当前激活的插件

let contextmenuKey = ''; // 右键菜单的key

let currentDialogData = null; // 当前dialog关联的数据


const websocket = new WebSocket(`ws://127.0.0.1:${config.serverPort}/deckClient`)
websocket.onopen = function (evt) {

};
websocket.onclose = function (evt) {

}

websocket.onmessage = function (evt) {
  const jsonObj = JSON.parse(evt.data)
  if (jsonObj.cmd === 'log') {
    log(jsonObj)
  }
  if (jsonObj.cmd === 'listUpdated') {
    listUpdated(jsonObj.data)
  }
  if (jsonObj.cmd === 'init') {
    config = jsonObj.config
    activeKeys = jsonObj.activeKeys
    initRender()
  }
  if (jsonObj.cmd === 'state') {
    setStateIcon(jsonObj.param.statelist[0])
  }
  if (jsonObj.cmd === 'connectedMain') {
    connectedMain(jsonObj.connectedMain)
  }
  if (jsonObj.cmd === 'openurl') {
    let url = getRelativePath(jsonObj.url)
    url = buildUrlParams(url, jsonObj.param)
    console.log('===openurl:', url)
    safeOpenWindow(url)
    log({
      time: time(),
      msg: `上位机收到openurl事件，新标签页打开一个新的窗口。由于浏览器限制，本地路径会打开失败，自查数据正确即可。以下是接收到的数据：`,
      code:JSON.stringify(jsonObj)
    })
  }
  if(jsonObj.cmd === 'selectdialog'){
    currentDialogData = jsonObj
    const dialog = document.querySelector('.select-dialog')
    dialog.style.display = 'flex'

    log({
      time: time(),
      msg: `上位机收到selectdialog事件，模拟打开一个选择文件/文件夹事件。请填写完整路径并确认，上位机会发送填写数据回请求端。以下是接收到的数据：`,
      code:JSON.stringify(jsonObj)
    })
  }
  if (jsonObj.cmd === 'openview') {
    let option = {
      width: jsonObj.width ,
      height: jsonObj.height 
    }
    if(jsonObj.x){
      option.position = {
        x: jsonObj.x,
        y: jsonObj.y || 0
      }
    }

    
    let url = getRelativePath(jsonObj.url)
    url = buildUrlParams(url, jsonObj.param)
    console.log('===openview:', url)
    
    openPopup(url,option)

    log({
      time: time(),
      msg: `上位机收到openview事件，弹出一个新的窗口。由于浏览器限制，本地路径会打开失败，自查数据正确即可。以下是接收到的数据：`,
      code:JSON.stringify(jsonObj)
    })
  }
  
}

function buildUrlParams(baseUrl, params = {}) {
  const queryString = Object.entries(params)
    .filter(([, value]) => value !== null && value !== undefined)
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
    .join('&');
  
  return queryString ? `${baseUrl}?${queryString}` : baseUrl;
}



function initRender(){
  setFormValue(config,form)
}

function connectedMain(data){
  for (const v of data) {
    const overlay = document.querySelector(`.slider-item-overlay[data-uuid="${v.UUID}"]`)
    overlay.style.display = 'none'
  }
}

function setStateIcon(iconData) {
  const data = iconData
  const { type, key } = data

  const uk = document.querySelector(`.ulanzi-key[data-key="${key}"]`)
  
  const ukImg = uk.getElementsByTagName('img')[0]
  let src = ''

  const { plugin, actionData, actionid, uuid } = activeKeys[key]

  if (type === 0) {
    //本地文件,状态列表
    src = `./${plugin}/${actionData.States[data.state].Image}`
  } else if ( type === 1) {
    //base64
    src = data.data
  } else if ( type === 3) {
    //gif base64
    src = data.gifdata
  } else if ( type === 2) {
    //本地绝对路径
    src = getRelativePath(data.path)
  } else if ( type === 4) {
    //本地gif绝对路径
    src = getRelativePath(data.gifpath)
  }
  if(!ukImg){
    uk.innerHTML = `<img src="${src}">`
  }else{
    ukImg.src = src
  }

}

function safeOpenWindow(url) {
  let win;
  try {
    win = window.open(url, '_blank');
  } catch (error) {
    console.warn('弹窗被浏览器拦截，请检查弹窗权限。');
  }

  if (!win || win.closed) {
    alert('由于浏览器限制，不在项目下的本地绝对路径无法打开。可自行复制路径打开，以下是完整路径：file:///' + url);
    return null;
  }

  win.focus();
  return win;

}


function openPopup(url, options = {}) {
  const {
    // 窗口尺寸
    width      = 800,
    height     = 600,

    // 相对位置：'center'|'top'|'bottom'|'left'|'right'|
    //           'top-left'|'top-right'|'bottom-left'|'bottom-right'
    // 或传入 { x, y } 使用绝对坐标
    position   = 'center',

    // 偏移量（在相对定位基础上微调）
    offsetX    = 0,
    offsetY    = 0,

    // 窗口名称（相同名称复用同一窗口）
    name       = 'popup_'+Date.now(),

    // 窗口特性
    scrollbars = 'yes',
    resizable  = 'yes',
    toolbar    = 'no',
    menubar    = 'no',
    status     = 'no',
  } = options;

  // console.log('===openPopup options:',url, options)

  // 屏幕可用区域（兼容多显示器）
  const screenW = window.screen.availWidth;
  const screenH = window.screen.availHeight;
  const screenX = window.screen.availLeft ?? 0;
  const screenY = window.screen.availTop  ?? 0;

  // 解析位置
  let left, top;

  if (typeof position === 'object' && position !== null) {
    // 绝对坐标模式
    left = position.x ?? 0;
    top  = position.y ?? 0;
  } else {
    // 相对定位模式
    const presets = {
      'center':       [screenX + (screenW - width)  / 2, screenY + (screenH - height) / 2],
      'top':          [screenX + (screenW - width)  / 2, screenY],
      'bottom':       [screenX + (screenW - width)  / 2, screenY + screenH - height],
      'left':         [screenX,                            screenY + (screenH - height) / 2],
      'right':        [screenX + screenW - width,           screenY + (screenH - height) / 2],
      'top-left':     [screenX,                            screenY],
      'top-right':    [screenX + screenW - width,           screenY],
      'bottom-left':  [screenX,                            screenY + screenH - height],
      'bottom-right': [screenX + screenW - width,           screenY + screenH - height],
    };
    [left, top] = presets[position] ?? presets['center'];
  }

  // 应用偏移
  left += offsetX;
  top  += offsetY;

  const features = [
    `width=${width}`,
    `height=${height}`,
    `left=${Math.round(left)}`,
    `top=${Math.round(top)}`,
    `scrollbars=${scrollbars}`,
    `resizable=${resizable}`,
    `toolbar=${toolbar}`,
    `menubar=${menubar}`,
    `status=${status}`,
  ].join(',');

  // console.log('===openPopup features:', features)

  safeOpenWindow(url, name, features);

}



//获取相对路径，适配上位机绝对路径
function getRelativePath(path){
  let rPath = path;
  const sStr = 'UlanziDeckSimulator/plugins/';

  if(rPath.indexOf(sStr) >= 0){
    rPath = rPath.split(sStr)[1]
  }


  return rPath
}


async function listUpdated(data) {
  plugins = data
  let listBuffer = []
  for (const k in data) {
    const v = data[k]

    // console.log('===k',k)
    // console.log('===v',v)
    let renderDate = v[config.language +'_DATA'] ? v[config.language +'_DATA'] : v

    let liBuffer = []
    for (let i = 0; i < v.Actions.length; i++) {
      const action = renderDate.Actions[i] ? renderDate.Actions[i] : v.Actions[i]
      liBuffer.push(`<li class="draggable" draggable="true" data-action="${k + '___' + i}" title="${action.Tooltip}">
              <div class="icon-name action-icon">
                <img src="./${k}/${v.Actions[i]?.Icon}">
                <span>${action.Name}</span>
              </div>
            </li>`)
    }


    listBuffer.push(`
        <div class="ulanzi-slider-item">
          <div class="slider-item-title"  title="${renderDate.Description}">

            <div class="icon-name category-icon">
              <img src="./${k}/${v.Icon}">
              <span>${renderDate.Name}</span>
            </div>
          </div>
          <div class="slider-item-content">
            <ul class="slider-item-actions">
              ${liBuffer.join('')}
            </ul>
            <div class="slider-item-overlay" data-uuid="${v.UUID}">请先启动主服务</div>
          </div>
        </div>`)

  }
  document.querySelector("#ulanzi-list").innerHTML = listBuffer.join('')
  initializeDraggables()
}



function log(data) {

  // 创建一个新的div元素
  const logItem = document.createElement('div');
  logItem.className = 'log-item';

  // 创建时间显示的p标签
  const logTime = document.createElement('p');
  logTime.className = 'log-time';
  logTime.textContent = `[${data.time}]`;
  logItem.appendChild(logTime);

  // 创建日志信息的p标签
  const logText = document.createElement('p');
  logText.textContent = data.msg;
  logItem.appendChild(logText);

  if (data.code) {
    // 创建代码框div
    const codeBox = document.createElement('div');
    codeBox.className = 'fence-box code-box';

    // 创建代码显示的span标签
    const codeSpan = document.createElement('span');
    codeSpan.textContent = data.code;
    codeBox.appendChild(codeSpan);
    logItem.appendChild(codeBox);
  }


  // 将创建好的logItem添加到目标节点中
  ulanziLog.insertBefore(logItem, ulanziLog.firstChild);
}

function toast(msg) {
  const tt = document.querySelector("#toast")
  tt.innerHTML = msg
  tt.style.display = "block"
  setTimeout(() => {
    tt.style.display = "none"
  }, 2000)
}

function time() {
  return new Date().toLocaleString('zh-CN', { hour12: false })
}



function getFormValue(form) {
  if (typeof form === 'string') {
    form = document.querySelector(form);
  }

  const elements = form ? form.elements : '';

  if (!elements) {
    console.error('Could not find form!');
  }

  const formData = new FormData(form);
  let formValue = {};

  formData.forEach((value, key) => {
    if (!Reflect.has(formValue, key)) {
      formValue[key] = value;
      return;
    }
    if (!Array.isArray(formValue[key])) {
      formValue[key] = [formValue[key]];
    }
    formValue[key].push(value);
  });

  return formValue;
}

function setFormValue(jsn, form) {
  if (!jsn) {
    return;
  }

  if (typeof form === 'string') {
    form = document.querySelector(form);
  }

  const elements = form ? form.elements:'';

  if (!elements) {
    console.error('Could not find form!');
  }

  Array.from(elements)
    .filter((element) => element?element.name:null)
    .forEach((element) => {
      const { name, type } = element;
      const value = name in jsn ? jsn[name] : null;
      const isCheckOrRadio = type === 'checkbox' || type === 'radio';

      if (value === null) return;

      if (isCheckOrRadio) {
        const isSingle = value === element.value;
        if (isSingle || (Array.isArray(value) && value.includes(element.value))) {
          element.checked = true;
        }
      } else {
        element.value = value ? value : '';
      }
    });
}



document.addEventListener('DOMContentLoaded', function () {


  ulanziLog = document.getElementById('ulanzi-log')


  log({
    time: time(),
    msg: '正在连接上位机模拟器...',
  })

  ulanziLog.addEventListener('click', async function (event) {
    // 检查点击的目标是否是 .code-box 或其子元素
    const codeBox = event.target.closest('.code-box');
    if (codeBox) {
      // 获取要复制的文本内容
      const textToCopy = codeBox.querySelector('span').innerText;

      try {
        // 复制文本到剪贴板
        await navigator.clipboard.writeText(textToCopy);
        toast('复制成功！');
      } catch (err) {
        console.error('复制失败:', err);
        toast('复制失败，请尝试手动复制。');
      }
    }
  });

  //监听配置变化
  form = document.getElementById('ulanzi-config')
  form.addEventListener(
    'input',
    () => {
      const value = getFormValue(form);
      
      config = {
        ...config,
        ...value
      }
      send('config', { config })
      handleActiveCurrentKey()
    })


  //拖拽事件

  const ulanziKey = document.querySelectorAll('.ulanzi-key');
  customMenu = document.getElementById('custom-menu');
  // 目标区域的处理
  ulanziKey.forEach(uk => {
    uk.addEventListener('dragover', function (e) {
      e.preventDefault(); // 阻止默认行为以允许放置
    });

    uk.addEventListener('drop', function (e) {
      const index = uk.dataset.index
      const keyValue = keys[index]
      e.preventDefault();
      const data = e.dataTransfer.getData('text/plain'); // 获取拖拽的数据
      const plugin_action = data.split('___');
      const plugin = plugin_action[0];
      const action = plugin_action[1];
      const actionData = plugins[plugin].Actions[action];
      const src = actionData.States[0].Image ?? actionData.Icon
      this.innerHTML = `<img src="./${plugin}/${src}">`; // 将数据放入目标区域

      log({
        time: time(),
        msg: `${actionData.UUID}拖入键盘，键值是${keyValue.key}，actionid是${keyValue.actionid}。上位机向主服务发送add和paramfromapp事件。请使用浏览器打开以下路径，调试该action。`,
        code: `http://127.0.0.1:${config.serverPort}/${plugin}/${actionData.PropertyInspectorPath}?mode=simulate&address=127.0.0.1&port=${config.serverPort}&language=${config.language}&uuid=${actionData.UUID}&actionid=${keyValue.actionid}&key=${keyValue.key}`
      })
      send('add', { uuid: actionData.UUID, key: keyValue.key, actionid: keyValue.actionid })
      activeKeys[keyValue.key] = { uuid: actionData.UUID, key: keyValue.key, actionid: keyValue.actionid, plugin, actionData }
      send('activeKeys',{activeKeys})
      currentActiveKey = keyValue.key
      handleActiveCurrentKey()
    });

    //右键
    uk.addEventListener('contextmenu', function (event) {
      event.preventDefault();
      const imgLength = uk.getElementsByTagName('img')
      if (imgLength.length > 0) {
        showCustomMenu(event);
        contextmenuKey = uk.dataset.key
      }
    });

    //点击
    uk.addEventListener('click', function (event) {
      event.preventDefault();
      const imgLength = uk.getElementsByTagName('img')
      if (imgLength.length > 0) {
        showCustomMenu(event);
        currentActiveKey = uk.dataset.key
        handleActiveCurrentKey()
      }
    });


  });

  // 隐藏菜单
  document.addEventListener('click', function () {
    hideCustomMenu();
  });

  // 处理菜单项点击事件
  customMenu.addEventListener('click', function (event) {
    event.stopPropagation();
    const target = event.target;
    if (target.tagName === 'LI') {
      handleMenuItemClick(target.id);
    }
  });
})

function refreshList() {
  send('refreshList')
}

function send(cmd, data) {
  websocket.send(JSON.stringify({
    cmd,
    ...data
  }));
}

// 初始化单个可拖动节点
function initializeDraggable(draggable) {
  draggable.addEventListener('dragstart', function (e) {
    const dragImage = draggable.getElementsByTagName('img')[0];
    console.log('===dragImage', dragImage)
    const action = draggable.dataset.action
    // const img = new Image();
    // img.src = dragImage.src;
    // img.width = 32 ;
    // img.height = 32 ;
    e.dataTransfer.setData('text/plain', action); // 设置拖拽数据
    e.dataTransfer.setDragImage(dragImage, 20, 20); // 设置拖拽时显示的图像
    setTimeout(() => { this.style.opacity = '0.5'; }, 0); // 可视化拖动效果

  });

  draggable.addEventListener('dragend', function () {
    this.style.opacity = '1'; // 拖动结束恢复原样
  });
}

// 初始化所有已有的可拖动节点
function initializeDraggables() {
  const draggables = document.querySelectorAll('.draggable');
  draggables.forEach(initializeDraggable);
}

// 显示自定义菜单
function showCustomMenu(event) {
  customMenu.style.display = 'block';
  customMenu.style.left = event.pageX + 'px';
  customMenu.style.top = event.pageY + 'px';
}

// 隐藏自定义菜单
function hideCustomMenu() {
  customMenu.style.display = 'none';
}



// 处理菜单项点击的具体逻辑
function handleMenuItemClick(itemId) {
  const { uuid, key, actionid } = activeKeys[contextmenuKey]
  switch (itemId) {
    case 'menu-run':
      send('run', { uuid, key, actionid })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。模拟按钮短按，上位机向主服务依次发送以下事件：keydown -> run -> keyup`
      })
      break;
    // case 'menu-longPress':
    //   send('run', { uuid, key, actionid, longPress: true, longPressTime: 1000 })
    //   log({
    //     time: time(),
    //     msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[按钮长按]事件。`
    //   })
    //   break;
    case 'menu-keyDown':
      send('ulanzi-cmd', { uuid, key, actionid, tocmd:'keydown' })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[按钮按下]事件：keydown。`
      })
      break;
    case 'menu-keyUp':
      send('ulanzi-cmd', { uuid, key, actionid, tocmd:'keyup' })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[按钮松开]事件：keyup。`
      })
      break;
    case 'menu-dailDown':
      send('ulanzi-cmd', { uuid, key, actionid, tocmd:'daildown' })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[旋钮按下]事件：daildown。`
      })
      break;
    case 'menu-dailUp':
      send('ulanzi-cmd', { uuid, key, actionid, tocmd:'dailup' })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[旋钮松开]事件：dailup。`
      })
      break;
    case 'menu-dailLeft':
      send('ulanzi-cmd', { uuid, key, actionid, tocmd:'dialrotate', rotateEvent:'left' })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[旋钮向左旋转]事件：dialrotate|left。`
      })
      break;
    case 'menu-dailRight':
      send('ulanzi-cmd', { uuid, key, actionid, tocmd:'dialrotate', rotateEvent:'right' })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[旋钮向右旋转]事件：dialrotate|right。`
      })
      break;
    case 'menu-dailHoldLeft':
      send('ulanzi-cmd', { uuid, key, actionid, tocmd:'dialrotate', rotateEvent:'hold-left' })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[旋钮按压向左旋转]事件：dialrotate|hold-left。`
      })
      break;
    case 'menu-dailHoldRight':
      send('ulanzi-cmd', { uuid, key, actionid, tocmd:'dialrotate', rotateEvent:'hold-right' })
      log({
        time: time(),
        msg: `运行 ${uuid}___${key}___${actionid}。上位机向主服务发送[旋钮按压向右旋转]事件：dialrotate|hold-right。`
      })
      break;
    case 'menu-clear':
      send('clear', { "param": [{ uuid, key, actionid }] })
      log({
        time: time(),
        msg: `删除 ${uuid}___${key}___${actionid}。上位机向主服务发送clear事件。`
      })
      const element = document.querySelector('.ulanzi-key[data-key="' + key + '"]');
      element.removeChild(element.firstChild);
      if(contextmenuKey == currentActiveKey){
        document.querySelector('.action-iframe').innerHTML = ''
        currentActiveKey = ''
        handleActiveCurrentKey()
      }
      delete activeKeys[key]
      send('activeKeys',{activeKeys: activeKeys})
      break;
    case 'menu-setactive':
      send('setactive', { uuid, key, actionid, active: true })
      log({
        time: time(),
        msg: `设置活跃状态 ${uuid}___${key}___${actionid}。活跃状态触发时，有状态变化，主服务要更新icon。`
      })
      break;
    case 'menu-setnoactive':
      send('setactive', { uuid, key, actionid, active: false })
      log({
        time: time(),
        msg: `设置非活跃状态 ${uuid}___${key}___${actionid}。非活跃状态下，若有定时任务，主服务要保持后台静默运行，但是不用发送消息到上位机。`
      })
      break;
    default:
      break;
  }
  hideCustomMenu();
}


function handleActiveCurrentKey() {
  let activeElement = null;
  if (currentActiveKey) {
    activeElement = document.querySelector('.ulanzi-key[data-key="' + currentActiveKey + '"]');
    activeElement.classList.add('active');

    if (config.loadAction === 'yes') {
      const { plugin, actionData, actionid, key, uuid } = activeKeys[currentActiveKey]
      document.querySelector('.action-iframe').innerHTML = `<iframe src="http://127.0.0.1:${config.serverPort}/${plugin}/${actionData.PropertyInspectorPath}?mode=simulate&address=127.0.0.1&port=${config.serverPort}&language=${config.language}&uuid=${uuid}&actionid=${actionid}&key=${key}"></iframe>`
    }
  }


  // 使用 querySelectorAll 查找所有 .ulanzi-key 元素
  const allUlanziKeys = document.querySelectorAll('.ulanzi-key');

  // 遍历所有 .ulanzi-key 元素，删除 active 类名
  allUlanziKeys.forEach(element => {
    if (element !== activeElement) {
      element.classList.remove('active');
    }
  });


}

function onDialogClose(){
  const dialog = document.querySelector('.dialog')
  dialog.style.display = 'none'
}

function onDialogOK(){
  console.log('---currentDialogData',currentDialogData)
  const dialog = document.querySelector('.dialog')
  const textarea = dialog.querySelector('textarea')
  const value = textarea.value
  send('selectdialog', { path: value.trim().replace(/\\/g, '/'), ...currentDialogData  })
  dialog.style.display = 'none'
  textarea.value = ''
}

