
import EventEmitter from 'events';
import menu from './menu.js';
import DeckClient from './deckClient.js';
import utils from './utils.js';

export default class Clients extends EventEmitter {
  constructor(config) {
    super();

    this.config = config;
    this.clientList = {};  //存储插件列表
    this.contextDatas = {};  //存储插件数据

    this.activeKeys = {};//已使用的key
    

    this.deckClient = null; //上位机模拟器客户端

    this.plugins = menu.plugins;
    menu.on('listUpdated', (data) => {
      // console.log('=== listUpdatedmenu',data)
      this.plugins = data;
      this.deckClient && this.deckClient.listUpdated(data)
      this.checkMainState()
    })


    

  }

  addClient(client, type) {
    if (type === 'deckClient') {
      this.deckClient = new DeckClient(client);
      this.log('连接上位机模拟器成功！等待加载插件...')
      this.deckClient.send('init',{
        config:this.config,
        activeKeys:this.activeKeys
      })
      if (this.plugins) {
        this.deckClient.listUpdated(this.plugins);
        this.checkMainState()
      }
      if(Object.keys(this.activeKeys).length != 0){
        this.log('键盘重载，向已启动的主服务发送setactive事件，主服务应发送当前状态的icon数据。')
        for(const k in this.activeKeys){
          const {  uuid, key, actionid } = this.activeKeys[k]
          const mainUuid = this.getMainUuid(uuid)
          if (this.clientList[mainUuid] && this.clientList[mainUuid].readyState == 1){

            this.clientList[mainUuid].send(JSON.stringify({
              cmd: 'setactive',
              uuid, key, actionid, 
              active: true
            }))
          }
        }

      }
      this.deckClient.on('refreshList', () => {
        this.refreshList()
      })
      this.deckClient.on('add', (data) => {
        const { uuid,key,actionid } = data;
        this.currentAddKey = { uuid,key,actionid }
        const context = utils.encodeContext(data)
        const param = this.contextDatas[context] || null
        this.send('add',{
          uuid,key,actionid,param
        },true)
        this.send('paramfromapp',{
          uuid,key,actionid,param
        },true)
      })
      this.deckClient.on('activeKeys', (data) => {
        this.activeKeys = data.activeKeys
      })

      this.deckClient.on('run', (data) => {
        const { uuid,key,actionid } = data;
        const context = utils.encodeContext(data)
        const param = this.contextDatas[context] || null
        this.send('keydown',{
          uuid,key,actionid,param
        },true)
        this.send('run',{
          uuid,key,actionid,param
        },true)

        if(data.longPress){
          setTimeout(()=>{
            this.send('keyup',{
              uuid,key,actionid,param
            },true)
          },data.longPressTime || 600)
        }else{
          this.send('keyup',{
            uuid,key,actionid,param
          },true)
        }
      })

      this.deckClient.on('setactive', (data) => {
        this.send('setactive',data,true)
      })
      this.deckClient.on('clear', (data) => {
        const context = utils.encodeContext(data.param[0])
        delete this.contextDatas[context]
        this.send('clear',data,true)
      })

      this.deckClient.on('config', (data) => {
        const oldLanguage = this.config.language
        this.config = data.config;
        if(this.config.language != oldLanguage){
          this.log('正在切换插件语言环境...')
          menu.getList()
        }
      })


      //实体按键事件
      this.deckClient.on('ulanzi-cmd',(data) => {
        console.log('收到实体按键事件', data)
        const context = utils.encodeContext(data)
        const param = this.contextDatas[context] || null
        this.send(data.tocmd,{
          ...data,
          cmd: data.tocmd,
          param
        },true)
      })

      //发送选择文件/文件夹回调
      this.deckClient.on('selectdialog',(data) => {
        this.send('selectdialog',{
          code:0,
          "cmdType": "REQUEST",
          ...data
        })
      })

    }else{
      client.on('message', (msg)=>{
        const data = utils.parseJson(msg.toString());

        if(data.cmd === 'connected') {
          this.connected(client, data)
        }

        
        if(typeof data.code != 'undefined') return;
        if(data.cmd === 'state') {
          this.deckClient && this.deckClient.send('state', data)
          //回复
          this.replay(client,data)
        }
        if(data.cmd === 'paramfromplugin') {
          this.forwardMsg(data, client)
        }
        if(data.cmd === 'openurl') {
          this.deckClient.send('openurl',data)
        }
        if(data.cmd === 'openview') {
          this.deckClient.send('openview',data)
        }
        if(data.cmd === 'sendToPlugin') {
          this.forwardMsg(data, client)
        }
        if(data.cmd === 'sendToPropertyInspector') {
          this.forwardMsg(data, client)
        }
        if(data.cmd === 'selectdialog') {
          this.deckClient.send('selectdialog',data)
        }
        if(data.cmd === 'setSettings') {
          const forwardCmd = 'didReceiveSettings'
          this.forwardMsg(data, client,forwardCmd)
        }
        if(data.cmd === 'getSettings') {
          const { uuid, actionid, key } = data;
          const context = utils.encodeContext(data)
          const oldParam = this.contextDatas[context]
          client.send(JSON.stringify({
            "cmd": "didReceiveSettings",
            uuid,
            actionid,
            key,
            "settings":oldParam
          }))

          const mainUuid = this.getMainUuid(data.uuid)
          const isMainSend = this.clientList[mainUuid] == client  // 判断是不是主服务发送的
          this.log(`${isMainSend?'插件主服务':context} 发送 [getSettings]获取参数 事件。上位机将通过 didReceiveSettings 事件发送参数到请求端。以下是发送的数据：`,JSON.stringify({
            "cmd": "didReceiveSettings",
            uuid,
            actionid,
            key,
            "settings":oldParam
          }))
        }
        if(data.cmd === 'setGlobalSettings'){
          const forwardCmd = 'didReceiveGlobalSettings'
          const mainUuid = this.getMainUuid(data.uuid)
          this.contextDatas[mainUuid] = data.settings

          const isMainSend = this.clientList[mainUuid] == client  // 判断是不是主服务发送的
          if(isMainSend){
            //全局参数向同一插件的所有action转发
            for(const k in this.clientList){
              if(k.indexOf(mainUuid) != -1 && this.clientList[k].readyState == 1){
                const { uuid, actionid, key } = utils.decodeContext(k)
                this.clientList[k].send(JSON.stringify({
                  "cmd": forwardCmd,
                  uuid,
                  actionid,
                  key,
                  "settings":data.settings
                }))
              }
            }
          }else{
            this.clientList[mainUuid].send(JSON.stringify({
              "cmd": forwardCmd,
              uuid: mainUuid,
              actionid:'',
              key:'',
              "settings":data.settings
            }))
          }

          this.log(`${isMainSend?'插件主服务':context} 发送 [setGlobalSettings] 设置全局参数 事件。上位机将通过 ${forwardCmd} 事件转发到${isMainSend?'所有同插件下的action':'插件主服务'}。以下是发送的数据：`,JSON.stringify({
            "cmd": forwardCmd,
            "settings":oldParam
          }))

        }
        if(data.cmd === 'getGlobalSettings'){
          const forwardCmd = 'didReceiveGlobalSettings'
          const mainUuid = this.getMainUuid(data.uuid)
          const oldParam = this.contextDatas[mainUuid]
          client.send(JSON.stringify({
            "cmd": forwardCmd,
            uuid,
            actionid,
            key,
            "settings":oldParam
          }))

          const isMainSend = this.clientList[mainUuid] == client  // 判断是不是主服务发送的
          this.log(`${isMainSend?'插件主服务':context} 发送 [getGlobalSettings]获取全局参数 事件。上位机将通过 ${forwardCmd} 事件发送全局设置参数到请求端。以下是发送的数据：`,JSON.stringify({
            "cmd": forwardCmd,
            uuid,
            actionid,
            key,
            "settings":oldParam
          }))
        }

      });
      client.on('close', (msg)=>{
        // console.log('Received close from client:');
        for(const k in this.clientList){
          if(this.clientList[k] == client){
            delete this.clientList[k]
            break;
          }
        }
      });

    }
    // this.clients.push(client);
  }

  forwardMsg(data,  client, forwardCmd){
    const { uuid,param, cmd, settings } = data;
    forwardCmd = forwardCmd || cmd
    const context = utils.encodeContext(data)
    const oldParam = this.contextDatas[context]
    const saveTag = (forwardCmd === 'paramfromplugin' || forwardCmd === 'didReceiveSettings') ? true : false
    if(saveTag) this.contextDatas[context] = param || settings || oldParam

    const mainUuid = this.getMainUuid(uuid)

    //回复
    this.replay(client,{
      ...data,
    })

    const isMainSend = this.clientList[mainUuid] == client  // 判断是不是主服务发送的


    this.log(`${isMainSend?'插件主服务':context} 发送${data.cmd}事件。上位机将通过 ${forwardCmd} 事件转发给 ${isMainSend?context:'插件主服务'} ${saveTag?'，转发的数据上位机会保存下来，再次连接action页面会通过paramfromapp接收到之前的配置数据':''}。以下是转发的数据：`,JSON.stringify({
          ...data,
          cmd: forwardCmd
        }))
    //转发
    if(isMainSend){
      if (this.clientList[context] && this.clientList[context].readyState == 1){
        this.clientList[context].send(JSON.stringify({
          ...data,
          cmd: forwardCmd
        }))
      }
    }else{
      if (this.clientList[mainUuid] && this.clientList[mainUuid].readyState == 1){
        this.clientList[mainUuid].send(JSON.stringify({
          ...data,
          cmd: forwardCmd
        }))
      }
    }
  }


  connected(client, data){
    const { uuid,key,actionid } = data;
    const isMain = uuid.split('.').length == 4;
    if(isMain){
      this.log('主服务 '+uuid + ' 已连接！')
      this.clientList[uuid] = client;
      this.checkMainState('onlyCheck')
    }else{
      const context = utils.encodeContext(data)
      this.clientList[context] = client;
      const param = this.contextDatas[context] || null;
      if(this.activeKeys[key] && this.activeKeys[key].uuid === uuid && this.activeKeys[key].actionid === actionid){
        
        this.log(`配置项 ${uuid} 已连接！键值为${key}，actionid为${actionid}。上位机模拟器向该action页面和主服务再次发送paramfromapp事件。${param?'以下是重载数据':''}`
          ,param?JSON.stringify(param):null
        )
        this.send('paramfromapp',{
          uuid,key,actionid,param
        })
        this.send('paramfromapp',{
          uuid,key,actionid,param
        },true)
      }else{
        this.log(`配置项 ${uuid} 已连接！键值为${key}，actionid为${actionid}。上位机模拟器向该action页面发送add和paramfromapp事件。${param?'以下是重载数据':''}`
          ,param?param:null
        )
        this.send('add',{
          uuid,key,actionid,param
        })
        this.send('paramfromapp',{
          uuid,key,actionid,param
        })
      }
    }
  }


  refreshList() {
    this.log('正在加载插件列表...')
    menu.getList()
  }

  replay(client, data, request) {
     //回复
     client.send(JSON.stringify({
      ...data,
      cmdType: request?"REQUEST":"NOTIFY",
      code: 0
    }))
  }

  checkMainState(onlyCheck) {
    let connectedMain = []
    for (const k in this.plugins) {
      const v = this.plugins[k]
      const renderDate = this.config.language === 'zh_CN' && v.zhData ? v.zhData : v
  
      if (this.clientList[v.UUID] && this.clientList[v.UUID].readyState == 1) { //存在并且还是连接状态
          if(!onlyCheck)this.log(renderDate.Name + ' 主服务 '+ v.UUID +' 已连接！')
          connectedMain.push(v)
      } else {
          let code = ''
          let msg = ''
          if (v.CodePath.indexOf('.js') >= 0) {
              msg = renderDate.Name  + ' 主服务 '+ v.UUID +' 未连接，请到插件的根目录 ' + k +' 下运行以下代码启动主服务'
              code = `node ${v.CodePath} 127.0.0.1 ${this.config.serverPort} ${this.config.language}`
          } else {
              msg = renderDate.Name + ' 主服务 '+ v.UUID +' 未连接，请使用浏览器打开以下链接启动主服务'
              code = `http://127.0.0.1:${this.config.serverPort}/${k}/${v.CodePath}?address=127.0.0.1&port=${this.config.serverPort}&language=${this.config.language}&uuid=${v.UUID}`
          }
          if(!onlyCheck)this.log(msg, code)
      }
    }
    this.deckClient && this.deckClient.send('connectedMain', {connectedMain})
  }

  removeClient(client) {
    const index = this.clients.indexOf(client);
    if (index > -1) {
      this.clients.splice(index, 1);
    }
  }



  log(msg, code) {
    this.deckClient && this.deckClient.log(msg, code)
  }

  send(cmd, data, isMain) {
    let uuid = ''
    if(cmd === 'clear'){
      uuid = data.param[0].uuid
    }else{
      uuid = data.uuid
    }
    if(isMain){
      uuid = this.getMainUuid(uuid)
    }else{
      uuid = utils.encodeContext(data)
    }
    // console.log('send to client',cmd, data, 'uuid:', uuid)
    // console.log('current clientList', Object.keys(this.clientList))
    this.clientList[uuid] && this.clientList[uuid].send(JSON.stringify({
      cmd,
      ...data
    }))
    
  }


  getMainUuid(uuid){
    if(!uuid) return console.error('[UlanziDeck Tips]: uuid not found!');
    const parts = uuid.split('.'); // 将字符串按 . 分割成数组
    return parts.slice(0, 4).join('.');
  }
}